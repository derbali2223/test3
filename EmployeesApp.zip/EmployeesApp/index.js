const express = require('express');
//const app = express();
const jsonServer = require('json-server');
const cors = require('cors');

// Returns an Express server
var server = jsonServer.create();

const options = {
    origin: ['http://localhost:5500', 'http://localhost:8080'],
}
// Set default middlewares (logger, static, cors and no-cache)
server.use(cors(options)); //jsonServer.defaults());
//jsonServer.cors()
// Returns an Express router
var router = jsonServer.router('employees.json');

server.use(router);

server.listen(3000);