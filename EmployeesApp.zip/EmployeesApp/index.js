const express = require('express');
const app = express();
/*
app.get("/", (req, res) => {
    res.send("I will be shown on the Browser");
    console.log("I will be shown on the Terminal");
});

app.listen(3000);*/

var jsonServer = require('json-server');

// Returns an Express server
var server = jsonServer.create();

// Set default middlewares (logger, static, cors and no-cache)
server.use(jsonServer.defaults());

// Returns an Express router
var router = jsonServer.router('employees.json');

server.use(router);

server.listen(3000);